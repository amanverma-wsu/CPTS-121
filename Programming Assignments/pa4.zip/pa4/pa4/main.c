#include "header.h" // Include the header file with the declaration of our functions

int main(void) {
    srand(time(NULL)); // Seed the random number generator with the current time to ensure randomness

    print_game_rules(); // Display the game rules to the player

    // Get the initial bank balance from the user
    double bank_balance = get_bank_balance();
    double initial_bank_balance = bank_balance; // Store the initial bank balance for reference

    // Initialize game status and other variables
    int game_status = -1; // -1 means the game continues, 1 means the player wins, 0 means the player loses
    int point_value = 0; // This will store the point if the first roll is not a win/lose condition
    int roll_count = 0; // Track the number of rolls in the game

    while (1) { // Main game loop
        double wager = get_wager_amount(); // Ask the player for a wager amount for the upcoming roll

        // Ensure the wager does not exceed the player's current bank balance
        while (!check_wager_amount(wager, bank_balance)) {
            printf("Wager exceeds your balance. Try again.\n");
            wager = get_wager_amount(); // Prompt again if the wager is too high
        }

        // Roll two dice and calculate the sum
        int die1 = roll_die();
        int die2 = roll_die();
        int sum_dice = calculate_sum_dice(die1, die2);
        printf("Rolling... You rolled a %d + %d = %d\n", die1, die2, sum_dice);

        roll_count++; // Increment the roll count

        // If this is the first roll, determine if the player wins, loses, or sets a point
        if (roll_count == 1) {
            game_status = is_win_loss_or_point(sum_dice);
            if (game_status == -1) point_value = sum_dice; // If the game continues, set the point value
        }
        else { // For subsequent rolls, determine if the player wins, loses, or needs to roll again
            game_status = is_point_loss_or_neither(sum_dice, point_value);
        }

        // If the player wins
        if (game_status == 1) {
            bank_balance = adjust_bank_balance(bank_balance, wager, 1); // Add the wager to the bank balance
            chatter_messages(roll_count, 1, initial_bank_balance, bank_balance); // Display a win message
            break; // Exit the game loop
        }
        // If the player loses
        else if (game_status == 0) {
            bank_balance = adjust_bank_balance(bank_balance, wager, 0); // Subtract the wager from the bank balance
            chatter_messages(roll_count, 0, initial_bank_balance, bank_balance); // Display a loss message
            break; // Exit the game loop
        }
        // If the game continues
        else {
            chatter_messages(roll_count, -1, initial_bank_balance, bank_balance); // Display a message encouraging the player
        }
    }

    // Once the game loop ends, print the player's final bank balance
    printf("Game over. Your final bank balance is: $%.2f\n", bank_balance);
    return 0;
}
