#ifndef HEADER_H
#define HEADER_H
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/****************************************************************************
* Function: print_game_rules()                                               *
* Date Created: 2/27/2024													 *
* Date Last Modified: 3/2/2024												 *
* Description: This function prints the rules of the game of craps.          *
*                                                                            *
* Input parameters: None                                                     *
*                                                                            *
* Returns: None                                                              *
*                                                                            *
* Preconditions: None                                                        *
* Postconditions: The rules are printed to the console.                      *
*****************************************************************************/
void print_game_rules(void);

/****************************************************************************
* Function: get_bank_balance()                                               *
* Date Created: 2/27/2024													 *
* Date Last Modified: 3/2/2024												 *
* Description: Prompts the player for an initial bank balance.               *
*                                                                            *
* Input parameters: None                                                     *
*                                                                            *
* Returns: double - The initial bank balance entered by the player.          *
*                                                                            *
* Preconditions: None                                                        *
* Postconditions: The player's bank balance is obtained.                     *
*****************************************************************************/
double get_bank_balance(void);

/****************************************************************************
* Function: get_wager_amount()                                               *
* Date Created: 2/27/2024													 *
* Date Last Modified: 3/2/2024												 *
* Description: Prompts the player for a wager amount.                        *
*                                                                            *
* Input parameters: None                                                     *
*                                                                            *
* Returns: double - The wager amount entered by the player.                  *
*                                                                            *
* Preconditions: None                                                        *
* Postconditions: The player's wager amount is obtained.                     *
*****************************************************************************/
double get_wager_amount(void);

/****************************************************************************
* Function: check_wager_amount()                                             *
* Date Created: 2/27/2024													 *
* Date Last Modified: 3/2/2024												 *
* Description: Checks if the wager amount is within the player's balance.    *
*                                                                            *
* Input parameters:                                                          *
*   double wager - The wager amount                                          *
*   double balance - The player's current bank balance                       *
*                                                                            *
* Returns: int - 1 if the wager is within the balance, 0 otherwise.          *
*                                                                            *
* Preconditions: None                                                        *
* Postconditions: None
*****************************************************************************/
int check_wager_amount(double wager, double balance);

/****************************************************************************
* Function: roll_die()                                                       *
* Date Created: 2/27/2024													 *
* Date Last Modified: 3/2/2024												 *
* Description: Simulates rolling a six-sided die.                            *
*                                                                            *
* Input parameters: None                                                     *
*                                                                            *
* Returns: int - The value rolled on the die (between 1 and 6).              *
*                                                                            *
* Preconditions: None                                                        *
* Postconditions: None
*****************************************************************************/
int roll_die(void);

/****************************************************************************
* Function: calculate_sum_dice()                                             *
* Date Created: 2/27/2024													 *
* Date Last Modified: 3/2/2024												 *
* Description: Calculates the sum of two dice.                               *
*                                                                            *
* Input parameters:                                                          *
*   int die1_value - Value rolled on the first die                           *
*   int die2_value - Value rolled on the second die                          *
*                                                                            *
* Returns: int - The sum of the two dice.                                    *
*                                                                            *
* Preconditions: None                                                        *
* Postconditions: None
*****************************************************************************/
int calculate_sum_dice(int die1_value, int die2_value);

/****************************************************************************
* Function: is_win_loss_or_point()                                           *
* Date Created: 2/27/2024													 *
* Date Last Modified: 3/2/2024												 *
* Description: Determines the result of the first dice roll.                 *
*                                                                            *
* Input parameters:                                                          *
*   int sum_dice - The sum of the two dice                                   *
*                                                                            *
* Returns: int - 1 if the player wins, 0 if the player loses,                *
*                -1 if the player's roll establishes a point.                *
*                                                                            *
* Preconditions: None                                                        *
* Postconditions: None
*****************************************************************************/
int is_win_loss_or_point(int sum_dice);

/****************************************************************************
* Function: is_point_loss_or_neither()                                       *
* Date Created: 2/27/2024													 *
* Date Last Modified: 3/2/2024												 *
* Description: Determines the result of any successive roll after the first. *
*                                                                            *
* Input parameters:                                                          *
*   int sum_dice - The sum of the two dice                                   *
*   int point_value - The player's point value (established on first roll)   *
*                                                                            *
* Returns: int - 1 if the player makes their point,                          *
*                0 if the player loses by rolling a 7,                       *
*               -1 if neither condition is met and the game continues.       *
*                                                                            *
* Preconditions: None                                                        *
* Postconditions: None
*****************************************************************************/
int is_point_loss_or_neither(int sum_dice, int point_value);

/****************************************************************************
* Function: adjust_bank_balance()                                            *
* Date Created: 2/27/2024													 *
* Date Last Modified: 3/2/2024												 *
* Description: Adjusts the player's bank balance based on game outcome.      *
*                                                                            *
* Input parameters:                                                          *
*   double bank_balance - The player's current bank balance                  *
*   double wager_amount - The amount wagered by the player                   *
*   int add_or_subtract - Indicates whether to add, subtract, or leave       *
*                         the wager amount from/to the bank balance          *
*                                                                            *
* Returns: double - The adjusted bank balance.                               *
*                                                                            *
* Preconditions: None                                                        *
* Postconditions: None
*****************************************************************************/
double adjust_bank_balance(double bank_balance, double wager_amount, int add_or_subtract);

/****************************************************************************
* Function: chatter_messages()                                               *
* Date Created: 2/27/2024										             *
* Date Last Modified: 3/2/2024												 *
* Description: Displays messages based on game progress and outcome.         *
*                                                                            *
* Input parameters:                                                          *
*   int number_rolls - Number of rolls taken by the player                   *
*   int win_loss_neither - Result of the previous roll (1 for win,           *
*                          0 for loss, -1 for neither)                       *
*   double initial_bank_balance - Initial bank balance of the player         *
*   double current_bank_balance - Current bank balance of the player         *
*                                                                            *
* Returns: None                                                              *
*                                                                            *
* Preconditions: None                                                        *
* Postconditions: None														 *
*****************************************************************************/
void chatter_messages(int number_rolls, int win_loss_neither, double initial_bank_balance, double current_bank_balance);

#endif