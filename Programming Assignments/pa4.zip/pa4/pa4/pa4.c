#include "header.h" // Include the custom header file for function declarations

// Function to print the game rules
void print_game_rules(void) {
    // Display the rules of the game to the user
    printf("Game of Craps Rules:\n");
    printf("- Roll two dice.\n");
    printf("- On first roll, 7 or 11 wins, 2, 3, or 12 loses.\n");
    printf("- Any other number rolled becomes your 'point'.\n");
    printf("- Continue rolling to hit your 'point' to win before you roll a 7 and lose.\n");
}

// Function to get the player's bank balance
double get_bank_balance(void) {
    double balance;
    // Prompt the user to enter their initial bank balance
    printf("Enter your initial bank balance: $");
    scanf("%lf", &balance); // Read the balance from user input
    return balance; // Return the entered balance
}

// Function to get the wager amount from the player
double get_wager_amount(void) {
    double wager;
    // Ask the player to enter a wager for the game
    printf("Enter your wager: $");
    scanf("%lf", &wager); // Read the wager from user input
    return wager; // Return the entered wager
}

// Function to check if the wager is within the player's bank balance
int check_wager_amount(double wager, double balance) {
    // Check if the wager is less than or equal to the balance
    return wager <= balance;
}

// Function to simulate rolling a die
int roll_die(void) {
    // Return a random number between 1 and 6
    return (rand() % 6) + 1;
}

// Function to calculate the sum of two dice
int calculate_sum_dice(int die1_value, int die2_value) {
    // Return the sum of the values of the two dice
    return die1_value + die2_value;
}

// Function to determine the outcome of the first roll
int is_win_loss_or_point(int sum_dice) {
    // Determine the game status based on the sum of the dice
    switch (sum_dice) {
    case 7: case 11:
        return 1; // Win
    case 2: case 3: case 12:
        return 0; // Loss
    default:
        return -1; // Any other value is a "point"
    }
}

// Function to determine the outcome of subsequent rolls
int is_point_loss_or_neither(int sum_dice, int point_value) {
    // Check if the player wins, loses, or neither based on the point value and the sum of the dice
    if (sum_dice == point_value) return 1; // Win by making point
    else if (sum_dice == 7) return 0; // Loss by rolling 7
    else return -1; // Neither win nor loss, continue rolling
}

// Function to adjust the player's bank balance after a game round
double adjust_bank_balance(double bank_balance, double wager_amount, int add_or_subtract) {
    // Adjust the bank balance based on the game outcome
    if (add_or_subtract == 1) {
        return bank_balance + wager_amount; // Add wager to balance if won
    }
    else if (add_or_subtract == 0) {
        return bank_balance - wager_amount; // Subtract wager from balance if lost
    }
    else return bank_balance; // If neither, return the current balance (should not happen in normal gameplay)
}

// Function to display messages based on game progress and outcome
void chatter_messages(int number_rolls, int win_loss_neither, double initial_bank_balance, double current_bank_balance) {
    // Display different messages based on whether the player won, lost, or neither
    if (win_loss_neither == 1) {
        printf("You won! Current balance: $%.2f\n", current_bank_balance);
    }
    else if (win_loss_neither == 0) {
        printf("Sorry, you lost. Current balance: $%.2f\n", current_bank_balance);
    }
    else {
        // Encourage the player to keep playing based on their current balance compared to the initial balance
        if (current_bank_balance > initial_bank_balance) {
            printf("You're up big, now's the time to cash in your chips!\n");
        }
        else {
            printf("Aw cmon, take a chance!\n");
        }
    }
}
