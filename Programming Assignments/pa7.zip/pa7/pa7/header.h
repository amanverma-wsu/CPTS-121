#pragma once
#ifndef PokerGame
#define PokerGame

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h> 
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>


/*
Function: Game_rules()
-Description: Displays the rules of Draw-5 Poker, including the order of possible hands.
-Input parameters: None
-Returns: None
-Preconditions: The game is initiating and the player needs instructions.
-Postconditions: Rules have been displayed to the console.
*/
void Game_rules(void);

/*
Function: shuffle_deck()
-Description: Randomizes the order of the cards in a deck to ensure fair play.
-Input parameters: int deck[][13] (a 2D array representing suits and ranks of a card deck).
-Returns: None
-Preconditions: The deck array is initialized with zero or default values.
-Postconditions: The deck has been shuffled with each card assigned a unique position.
*/
void shuffle_deck(int deck[][13]);

/*
Function: deal_cards()
-Description: Deals cards to a hand from the shuffled deck.
-Input parameters: int deck[][13], int hand[][2], const char* suit[], const char* face[], int* card
-Returns: None
-Preconditions: The deck must be shuffled; 'card' points to the current card index to start dealing.
-Postconditions: The hand array is populated with cards from the deck.
*/
void deal_cards(int deck[][13], int hand[][2], const char* suit[], const char* face[], int*);

/*
Function: Pair()
-Description: Checks if there is a pair in the hand.
-Input parameters: int hand[][2], const char* suit[], const char* face[]
-Returns: int (1 if a pair is found, 0 otherwise)
-Preconditions: The hand is dealt.
-Postconditions: Determines if a pair is present in the hand.
*/
int Pair(int hand[][2], const char* suit[], const char* face[]);


/*
Function: Pairs()
-Description: Checks if there are two pairs in the hand.
-Input parameters: int hand[][2], const char* suit[], const char* face[]
-Returns: int (1 if two pairs are found, 0 otherwise)
-Preconditions: The hand is dealt.
-Postconditions: Determines if two pairs are present in the hand.
*/
int Pairs(int hand[][2], const char* suit[], const char* face[]);


/*
Function: Three_Of_A_Kind()
-Description: Checks if there are three cards of the same rank in the hand.
-Input parameters: int hand[][2], const char* suit[], const char* face[]
-Returns: int (1 if three of a kind is found, 0 otherwise)
-Preconditions: The hand is dealt.
-Postconditions: Determines if three of a kind is present in the hand.
*/
int Three_Of_A_Kind(int hand[][2], const char* suit[], const char* face[]);

/*
Function: Four_Of_A_Kind()
-Description: Checks if there are four cards of the same rank in the hand.
-Input parameters: int hand[][2], const char* suit[], const char* face[]
-Returns: int (1 if four of a kind is found, 0 otherwise)
-Preconditions: The hand is dealt.
-Postconditions: Determines if four of a kind is present in the hand.
*/
int Four_Of_A_Kind(int hand[][2], const char* suit[], const char* face[]);

/*
Function: Straight()
-Description: Checks if the hand contains five cards of sequential rank.
-Input parameters: int hand[][2], const char* suit[], const char* face[]
-Returns: int (1 if a straight is found, 0 otherwise)
-Preconditions: The hand is dealt.
-Postconditions: Determines if a straight is present in the hand.
*/
int Straight(int hand[][2], const char* suit[], char* face[]);

/*
Function: Flush()
-Description: Checks if the hand contains five cards of the same suit.
-Input parameters: int hand[][2], const char* suit[], const char* face[]
-Returns: int (1 if a flush is found, 0 otherwise)
-Preconditions: The hand is dealt.
-Postconditions: Determines if a flush is present in the hand.
*/
int Flush(int hand[][2], char* suit[], char* face[]);

/*
Function: Better_Hand()
-Description: Compares two hands to determine which one is better based on poker rules.
-Input parameters: int hand1[][2], int hand2[][2], const char* suit[], const char* face[]
-Returns: int (1 if hand1 is better, -1 if hand2 is better, 0 if they are equal)
-Preconditions: Both hands are dealt and evaluated.
-Postconditions: Determines the better hand between two given hands.
*/
int Better_Hand(int hand1[][2], int hand2[][2], const char* suit[], const char* face[]);

/*
Function: Check_hand()
-Description: Evaluates and prints the type of poker hand.
-Input parameters: int hand[][2], const char* suit[], const char* face[]
-Returns: None
-Preconditions: The hand is dealt.
-Postconditions: The type of poker hand is printed.
*/
void Check_hand(int hand[][2], const char* suit[], const char* face[]);

/*
Function: print_hand()
-Description: Prints the cards in a hand.
-Input parameters: int hand[][2], const char* suit[], const char* face[]
-Returns: None
-Preconditions: The hand is dealt.
-Postconditions: All cards in the hand are printed to the console.
*/

void print_hand(int hand[][2], const char* suit[], const char* face[]);





#endif