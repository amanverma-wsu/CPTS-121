/*
   Author: Aman Verma
   Class: Cpts 121 Lab section 7
   Date: 2/1/24
   Date Last Modified: 2/2/24
   Programming Assignment: Programming Assignment 2: Modular Equation Evaluator using 3 file method.

   Description:
   This source file contains the main driver function for the modular equation
   evaluator program. The program prompts the user for inputs to evaluate seven
   equations, handling various data types, utilizing a constant macro for PI, and
   including mathematical operations like square root.

*/

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include "header.h"  // Include the user-defined header file containing function prototypes

int main(void) {
    // Variable declarations for storing results
    int series_resistance;
    float sales_tax, parallel_resistance, equations, pyramid_volume, distance;
    char chr_encoding;




    // Prompt user and calculate total series resistance
    int r1, r2, r3;
    printf("Please enter the values of 3 resistors (All integers) connected in series): ");
    scanf("%d %d %d", &r1, &r2, &r3);
    // Call the function calculating_series_resistance with the user-input values for three resistors (r1, r2, r3)
    // Assign the result to the variable series_resistance
    series_resistance = calculating_series_resistance(r1, r2, r3);
    printf("Total series resistance: series_resistance = R1 + R2 + R3 = %d + %d + %d = %d\n", r1, r2, r3, series_resistance);




    // Prompt user and calculate total sales tax
    float sales_tax_rate, item_cost;
    printf("\nEnter values for sales_tax_rate and item_cost: ");
    scanf("%f %f", &sales_tax_rate, &item_cost);
    // Call the function total_sales_tax with the user-input values for sales_tax_rate and item_cost
    // Assign the result to the variable sales_tax
    sales_tax = total_sales_tax(item_cost, sales_tax_rate);
    printf("Sales tax: total_sales_tax = sales_tax_rate * item_cost = %f * %f = %f\n", sales_tax_rate, item_cost, sales_tax);




    // Prompt user and calculate volume of a right rectangular pyramid
    float height, width, length;
    printf("\nEnter the height, width, and length: ");
    scanf("%f %f %f", &height, &width, &length);
    // Call the function rectangular_pyramid_volume with the user-input values for height, width, and length
    // Assign the result to the variable pyramid_volume
    pyramid_volume = rectangular_pyramid_volume(height, width, length);
    printf("Volume of a right rectangular pyramid: volume_pyramid = (l * w * h) / 3 = (%f * %f * %f) / 3 = %f\n", length, width, height, pyramid_volume);




    // Prompt user and calculate total parallel resistance
    int R1, R2, R3;
    printf("\nEnter the values of 3 resistors connected in parallel (integer): ");
    scanf("%d %d %d", &R1, &R2, &R3);
    // Call the function calculating_parallel_resistance with the user-input values for three resistors in parallel (R1, R2, R3)
    // Assign the result to the variable parallel_resistance
    parallel_resistance = calculating_parallel_resistance(R1, R2, R3);
    printf("Total parallel resistance: parallel_resistance = 1 / (1 / R1 + 1 / R2 + 1 / R3) = 1 / (1 / %d + 1 / %d + 1 / %d): %f\n", R1, R2, R3, parallel_resistance);



    // Prompt user and calculate character encoding
    int shift = 0;
    char plaintext_character = '\0';
    printf("\nEnter the value for shift (an integer): ");
    scanf("%d", &shift);
    printf("Enter a plain text character: ");
    scanf(" %c", &plaintext_character);
    // Call the function character_encoding with the user-input values for shift and plaintext_character
    // Assign the result to the variable chr_encoding
    chr_encoding = character_encoding(shift, plaintext_character);
    printf("Character encoding: encoded_character = (plaintext_character � 'a') + 'A' - shift = (%c � 'a') + 'A' - %d = %c\n", plaintext_character, shift, chr_encoding);



    // Prompt user and calculate distance between two points
    float x1, x2, y1, y2;
    printf("\nEnter the values for x1 and x2: ");
    scanf("%f %f", &x1, &x2);
    printf("Enter the values for y1 and y2: ");
    scanf("%f %f", &y1, &y2);
    // Call the function calculating_distance with the user-input values for x1, x2, y1, and y2
    // Assign the result to the variable distance
    distance = calculating_distance(x1, x2, y1, y2);
    printf("Distance = sqrt((%f - %f)^2 + (%f - %f)^2) = %f\n", x1, x2, y1, y2, distance);



    // Prompt user and calculate result of the general equation
    int a = 0;
    float x = 0.0, z = 0.0, y = 0.0;
    printf("\nEnter the value for 'a' (an integer): ");
    scanf("%d", &a);
    printf("Enter the value of x, y, z: ");
    scanf("%f %f %f", &x, &y, &z);
    // Call the function general_equation with the user-input values for 'a', 'x', 'y', and 'z'
    // Assign the result to the variable equations
    equations = general_equation(a, x, y, z);
    printf("General equation: y = y / (3 / 17) - %f + %f / (%d %% 2) + PI = %f\n", z, x, a, equations);

    return 0;
}
