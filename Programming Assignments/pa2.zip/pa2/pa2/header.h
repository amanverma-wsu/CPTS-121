/*
   Author: Aman Verma
   Class: Cpts 121 Lab section 7
   Date: 1/2/24
   Date Last Modified: 2/2/24
   Programming Assignment: Programming Assignment 2: Modular Equation Evaluator Using 3 file method.

   Description:
   This header file contains function prototypes and necessary #includes for the
   modular equation evaluator program. The program prompts the user for inputs to
   evaluate seven equations, handling various data types, utilizing a constant macro
   for PI, and including mathematical operations like square root.

*/


#ifndef HEADER_H
#define HEADER_H

#include <stdio.h>
#include <math.h>

#define PI 3.14159 // Constant macro for PI

// Function prototypes
int calculating_series_resistance(int r1, int r2, int r3);
float total_sales_tax(float item_cost, float sales_tax_rate);
float rectangular_pyramid_volume(float height, float width, float length);
float calculating_parallel_resistance(int R1, int R2, int R3);
char character_encoding(int shift, char plaintext_character);
float calculating_distance(float x1, float x2, float y1, float y2);
float general_equation(int a, float x, float y, float z);

#endif
