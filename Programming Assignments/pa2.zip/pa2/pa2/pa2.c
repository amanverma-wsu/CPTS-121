/*
   Author: Aman Verma
   Class: Cpts 121 Lab section 7
   Date: 2/1/24
   Date Last Modified: 2/2/24
   Programming Assignment: Programming Assignment 2: Modular Equation Evaluator using 3 file method.

   Description:
   This source file contains the implementations of functions for the modular equation
   evaluator program. The program prompts the user for inputs to evaluate seven
   equations, handling various data types, utilizing a constant macro for PI, and
   including mathematical operations like square root.

*/


#define _CRT_SECURE_NO_WARNINGS
#include "header.h"
#include <stdio.h>
#include <math.h>



/*****************************************************************************
* Function: calculating_series_resistance()                                  *
* Date Created:                                                              *
* Date Last Modified:                                                        *
* Description: This function takes the values of three resistors (r1, r2, r3)*
*              and calculates the total resistance when they are connected in*
*              series.                                                       *
*                                                                            *
* Input parameters:                                                          *
*   int r1 - The value of the first resistor                                 *
*   int r2 - The value of the second resistor                                *
*   int r3 - The value of the third resistor                                 *
*                                                                            *
* Returns: The total series resistance                                       *
*                                                                            *
* Preconditions: None                                                        *
* Postconditions: The total resistance in series is returned.                *
******************************************************************************/
int calculating_series_resistance(int r1, int r2, int r3) {
    int total_series_resistance = r1 + r2 + r3;
    return total_series_resistance;
}


/*****************************************************************************
* Function: rectangular_pyramid_volume()                                     *
* Date Created:                                                              *
* Date Last Modified:                                                        *
* Description: This function takes the height, width, and length of a right  *
*              rectangular pyramid and calculates its volume.                *
*                                                                            *
* Input parameters:                                                          *
*   int height - The height of the pyramid                                   *
*   int width - The width of the pyramid                                     *
*   int length - The length of the pyramid                                   *
*                                                                            *
* Returns: The volume of the right rectangular pyramid                       *
*                                                                            *
* Preconditions: None                                                        *
* Postconditions: The volume of the pyramid is returned.                     *
******************************************************************************/
float rectangular_pyramid_volume(float height, float width, float length) {
    float volume_pyramid = (length * width * height) / 3;
    return volume_pyramid;
}

/*****************************************************************************
* Function: total_sales_tax()                                                *
* Date Created:                                                              *
* Date Last Modified:                                                        *
* Description: This function takes the cost of an item and the sale tax rate *
*              to calculate the total sales tax.                             *
*                                                                            *
* Input parameters:                                                          *
*   float item_cost - The cost of the item                                   *
*   float sales_tax_rate - The sales tax rate                                *
*                                                                            *
* Returns: The total sales tax                                               *
*                                                                            *
* Preconditions: None                                                        *
* Postconditions: The total sales tax is returned.                           *
******************************************************************************/
float total_sales_tax(float item_cost, float sales_tax_rate) {
    float total_sales_tax = sales_tax_rate * item_cost;
    return total_sales_tax;
}



/*****************************************************************************
* Function: calculating_parallel_resistance()                                *
* Date Created:                                                              *
* Date Last Modified:                                                        *
* Description: This function takes the values of three resistors (R1, R2, R3)*
*              and calculates the total parallel resistance.                 *
*                                                                            *
* Input parameters:                                                          *
*   int R1 - The value of the first resistor                                 *
*   int R2 - The value of the second resistor                                *
*   int R3 - The value of the third resistor                                 *
*                                                                            *
* Returns: The total parallel resistance                                     *
*                                                                            *
* Preconditions: None                                                        *
* Postconditions: The total parallel resistance is returned.                 *
******************************************************************************/
float calculating_parallel_resistance(int R1, int R2, int R3) {
    float parallel_resistance = 1 / (1 / (float)R1 + 1 / (float)R2 + 1 / (float)R3);
    return parallel_resistance;
}

/*****************************************************************************
* Function: character_encoding()                                             *
* Date Created:                                                              *
* Date Last Modified:                                                        *
* Description: This function takes a shift value and a plain text character, *
*              and encodes the character based on the shift.                 *
*                                                                            *
* Input parameters:                                                          *
*   int shift - The shift value for encoding                                 *
*   char plaintext_character - The plain text character to be encoded        *
*                                                                            *
* Returns: The encoded character                                             *
*                                                                            *
* Preconditions: None                                                        *
* Postconditions: The encoded character is returned.                         *
******************************************************************************/
char character_encoding(int shift, char plaintext_character) {
    return (plaintext_character - 'a') + 'A' - shift;
}


/*****************************************************************************
* Function: calculating_distance()                                           *
* Date Created:                                                              *
* Date Last Modified:                                                        *
* Description: This function takes the coordinates of two points (x1, x2, y1,*
*              y2) and calculates the distance between them.                 *
*                                                                            *
* Input parameters:                                                          *
*   float x1 - The x-coordinate of the first point                           *
*   float x2 - The x-coordinate of the second point                          *
*   float y1 - The y-coordinate of the first point                           *
*   float y2 - The y-coordinate of the second point                          *
*                                                                            *
* Returns: The distance between the two points                               *
*                                                                            *
* Preconditions: None                                                        *
* Postconditions: The distance between the two points is returned.           *
******************************************************************************/
float calculating_distance(float x1, float x2, float y1, float y2) {
    return sqrt(pow(x1 - x2, 2) + pow(y1 - y2, 2));
}


/*****************************************************************************
* Function: general_equation()                                               *
* Date Created:                                                              *
* Date Last Modified:                                                        *
* Description: This function takes values for 'a', 'x', 'y', and 'z' and     *
*              evaluates a general mathematical equation.                    *
*                                                                            *
* Input parameters:                                                          *
*   int a - The value for 'a'                                                *
*   float x - The value for 'x'                                              *
*   float y - The value for 'y'                                              *
*   float z - The value for 'z'                                              *
*                                                                            *
* Returns: The result of the general equation                                *
*                                                                            *
* Preconditions: None                                                        *
* Postconditions: The result of the equation is returned.                    *
******************************************************************************/
float general_equation(int a, float x, float y, float z) {
    float constant_3 = 3.0;
    float constant_17 = 17.0;
    return y / (constant_3 / constant_17) - z + x / (float)(a % 2) + PI;
}

