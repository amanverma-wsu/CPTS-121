#define _CRT_SECURE_NO_WARNINGS
#ifndef YAHTZEE_H
#define YAHTZEE_H

#define MAX_ROUNDS 13
#define DICE_COUNT 5
#define COMBINATIONS 13
#define UPPER_SCORE_BONUS 35
#define UPPER_SECTION_THRESHOLD 63
#define YAHTZEE_BONUS 100
#define YAHTZEE_SCORE 50

// Enum for scoring combinations
typedef enum {
    ONES, TWOS, THREES, FOURS, FIVES, SIXES,
    THREE_OF_A_KIND, FOUR_OF_A_KIND, FULL_HOUSE,
    SMALL_STRAIGHT, LARGE_STRAIGHT, YAHTZEE, CHANCE
} ScoringCombination;

// Player structure
typedef struct {
    int scorecard[COMBINATIONS];
    int used[COMBINATIONS];
    int upperScore;
    int lowerScore;
    int totalScore;
    int yahtzeeBonusCount;
} Player;

// Function prototypes
void printMenu();
void printRules();
void startGame(Player players[], int numPlayers);
void rollDice(int dice[]);
void displayDice(int dice[]);
int selectCombination(Player* player, int dice[]);
void calculateScore(Player* player, int combination, int dice[]);
int sumOfDice(int dice[], int face);
void updateScores(Player* player);
void printScores(Player players[], int numPlayers);
int determineWinner(Player players[], int numPlayers);
int checkCombination(int dice[], ScoringCombination combination);
void clearScreen();

#endif // YAHTZEE_H
