#include "yahtzee.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    // Initialize random number generator for the game's dice rolls.
    srand(time(NULL));

    // Create an array for two players, initializing their structures.
    Player players[2] = { 0 };

    int choice; // Variable to store the user's menu choice.

    do {
        printMenu(); // Display the main game menu.
        scanf("%d", &choice); // Read the user's choice.
        getchar(); // Consume the trailing newline character from the input buffer.

        switch (choice) {
        case 1:
            // If the user selects 1, print the game rules.
            printRules();
            break;
        case 2:
            // If the user selects 2, start the Yahtzee game.
            startGame(players, 2);
            break;
        case 3:
            // If the user selects 3, exit the game.
            printf("Exiting game...\n");
            break;
        default:
            // If the user enters an invalid choice, prompt them again.
            printf("Invalid choice. Please try again.\n");
        }
    } while (choice != 3); // Continue until the user chooses to exit.

    return 0; // End of the program.
}
