#include "yahtzee.h"
#include <stdio.h>
#include <stdlib.h>

void printMenu() {
    printf("\nYahtzee Game\n");
    printf("1. Print Rules\n");
    printf("2. Start Game\n");
    printf("3. Exit\n");
    printf("Enter your choice: ");
}

void printRules() {
    printf("\n--- Yahtzee Rules ---\n");
    printf("Press Enter to return to the menu...\n");
    getchar();  // Wait for Enter
}
// Starts the game of Yahtzee for the given players.
void startGame(Player players[], int numPlayers) {
    // Initialize players
    for (int i = 0; i < numPlayers; ++i) {
        for (int j = 0; j < COMBINATIONS; ++j) {
            players[i].scorecard[j] = 0;
            players[i].used[j] = 0;
        }
        players[i].upperScore = 0;
        players[i].lowerScore = 0;
        players[i].totalScore = 0;
        players[i].yahtzeeBonusCount = 0;
    }

    // Main game loop
    int dice[DICE_COUNT];
    for (int round = 0; round < MAX_ROUNDS; ++round) {
        for (int i = 0; i < numPlayers; ++i) {
            printf("\nPlayer %d's turn (Round %d):\n", i + 1, round + 1);
            int rollCount = 0;
            while (rollCount < 3) {
                rollDice(dice);
                displayDice(dice);
                rollCount++;

                if (rollCount < 3) {
                    char choice;
                    printf("Keep this roll? (y/n): ");
                    scanf(" %c", &choice);  // Space to consume newline
                    if (choice == 'y' || choice == 'Y') {
                        break;
                    }
                }
            }

            int combination = selectCombination(&players[i], dice);
            calculateScore(&players[i], combination, dice);
            updateScores(&players[i]);
        }
    }

    printScores(players, numPlayers);
    int winner = determineWinner(players, numPlayers);
    printf("Player %d wins!\n", winner + 1);
}

// Rolls the dice, generating a random value for each die.
void rollDice(int dice[]) {
    for (int i = 0; i < DICE_COUNT; ++i) {
        dice[i] = rand() % 6 + 1;
    }
}

// Displays the current values of the dice.
void displayDice(int dice[]) {
    printf("Dice: ");
    for (int i = 0; i < DICE_COUNT; ++i) {
        printf("%d ", dice[i]);
    }
    printf("\n");
}

// Allows the player to select a scoring combination.
int selectCombination(Player* player, int dice[]) {
    int choice;
    do {
        printf("Select a combination: \n");
        for (int i = 0; i < COMBINATIONS; ++i) {
            if (!player->used[i]) {
                printf("%d. Combination %d\n", i + 1, i + 1);  // Replace with actual combination names if needed
            }
        }
        printf("Your choice: ");
        scanf("%d", &choice);
        --choice;  // Adjust for 0-based index
    } while (choice < 0 || choice >= COMBINATIONS || player->used[choice]);

    player->used[choice] = 1;
    return choice;
}

// Calculates the score for the player based on the chosen combination.
void calculateScore(Player* player, int combination, int dice[]) {
    int score = 0;
    // Implement scoring logic based on the combination
    // Example for ONES:
    if (combination == ONES) {
        score = sumOfDice(dice, 1);
    }
    // ... Add cases for other combinations ...

    player->scorecard[combination] = score;
}

// Sums the dice that have the specified face value.
int sumOfDice(int dice[], int face) {
    int sum = 0;
    for (int i = 0; i < DICE_COUNT; ++i) {
        if (dice[i] == face) {
            sum += face;
        }
    }
    return sum;
}

// Updates the scores of the player including upper, lower, and total scores.
void updateScores(Player* player) {
    player->upperScore = 0;
    player->lowerScore = 0;
    for (int i = 0; i < COMBINATIONS; ++i) {
        if (i < SIXES) { // Assuming SIXES is the last upper section combination
            player->upperScore += player->scorecard[i];
        }
        else {
            player->lowerScore += player->scorecard[i];
        }
    }

    // Check for upper score bonus
    if (player->upperScore >= UPPER_SECTION_THRESHOLD) {
        player->totalScore = player->upperScore + player->lowerScore + UPPER_SCORE_BONUS;
    }
    else {
        player->totalScore = player->upperScore + player->lowerScore;
    }
}

// Prints the current scores of all players.
void printScores(Player players[], int numPlayers) {
    printf("\nScores:\n");
    for (int i = 0; i < numPlayers; ++i) {
        printf("Player %d: Upper = %d, Lower = %d, Total = %d\n",
            i + 1, players[i].upperScore, players[i].lowerScore, players[i].totalScore);
    }
}

// Determines the winner of the game based on the highest score.
int determineWinner(Player players[], int numPlayers) {
    int winnerIndex = 0;
    int highScore = 0;

    for (int i = 0; i < numPlayers; ++i) {
        if (players[i].totalScore > highScore) {
            highScore = players[i].totalScore;
            winnerIndex = i;
        }
    }

    return winnerIndex;
}

// Counts how many dice show a specific face value.
int countDice(int dice[], int faceValue) {
    int count = 0;
    for (int i = 0; i < DICE_COUNT; ++i) {
        if (dice[i] == faceValue) {
            ++count;
        }
    }
    return count;
}

// Checks if the dice form a sequence of a specified length.
int isSequence(int dice[], int length) {
    int counts[6] = { 0 }; // One count for each die face
    for (int i = 0; i < DICE_COUNT; ++i) {
        counts[dice[i] - 1]++;
    }

    int consecutive = 0;
    for (int i = 0; i < 6; ++i) {
        if (counts[i] > 0) {
            consecutive++;
            if (consecutive == length) {
                return 1;
            }
        }
        else {
            consecutive = 0;
        }
    }
    return 0;
}


// Checks if a specific scoring combination is achieved with the current dice.
int checkCombination(int dice[], ScoringCombination combination) {
    switch (combination) {
    case ONES:
    case TWOS:
    case THREES:
    case FOURS:
    case FIVES:
    case SIXES:
        // These are handled in calculateScore, so always return true.
        return 1;
    case THREE_OF_A_KIND:
    case FOUR_OF_A_KIND:
        for (int i = 1; i <= 6; ++i) {
            if (countDice(dice, i) >= (combination == THREE_OF_A_KIND ? 3 : 4)) {
                return 1;
            }
        }
        return 0;
    case FULL_HOUSE:
    {
        int hasThree = 0, hasTwo = 0;
        for (int i = 1; i <= 6; ++i) {
            int count = countDice(dice, i);
            if (count == 3) hasThree = 1;
            if (count == 2) hasTwo = 1;
        }
        return hasThree && hasTwo;
    }
    case SMALL_STRAIGHT:
        return isSequence(dice, 4);
    case LARGE_STRAIGHT:
        return isSequence(dice, 5);
    case YAHTZEE:
        for (int i = 1; i <= 6; ++i) {
            if (countDice(dice, i) == 5) {
                return 1;
            }
        }
        return 0;
    case CHANCE:
        // Chance always applies
        return 1;
    default:
        return 0;
    }
}

// Clears the terminal screen.
void clearScreen() {
// Windows System
    system("cls");
}
