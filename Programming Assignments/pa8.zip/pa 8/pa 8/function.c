#include <stdio.h>
#include <string.h>
#include <math.h> 
#include "header.h" 

// Find the longest sequence of consecutive integers in a matrix
void max_consecutive_integers(int** matrix, int rows, int cols, int* start_address, int* count) {
    int max_count = 0; 
    int max_start_row = 0; 
    int max_start_col = 0;

    // Iterate over rows
    for (int i = 0; i < rows; i++) {
        int current_count = 1;
        for (int j = 1; j < cols; j++) {
            if (matrix[i][j] == matrix[i][j - 1]) {
                current_count++;
            }
            else {
                if (current_count > max_count) {
                    max_count = current_count;
                    max_start_row = i;
                    max_start_col = j - current_count;
                }
                current_count = 1;
            }
        }

        // Check end-of-row sequence
        if (current_count > max_count) {
            max_count = current_count;
            max_start_row = i;
            max_start_col = cols - current_count;
        }
    }

    int base_address = 1000; 
    *start_address = base_address + (max_start_row * cols + max_start_col) * 4;
    *count = max_count; 
}

// Concatenate 'n' characters from 'src' to the end of 'destination'
char* my_str_n_cat(char* destination, const char* src, int n) {
    // Find the end of the destinationination stringing
    char* destination_end = destination;
    while (*destination_end != '\0') {
        destination_end++;
    }

    // Append up to 'n' characters from the source
    const char* src_ptr = src;
    int count = 0;
    while (count < n && *src_ptr != '\0') {
        *destination_end = *src_ptr; 
        destination_end++;
        src_ptr++;
        count++;
    }

    *destination_end = '\0'; 
    return destination;
}

// Perform binary search to find a target value in a sorted array
int binary_search(const int arr[], int size, int target) {
    int left = 0; 
    int right = size - 1;
    int found = 0; 
    int target_index = -1; 

    while (!found && left <= right) {
        int mid = left + (right - left) / 2;

        if (arr[mid] == target) { 
            found = 1;
            target_index = mid;
        }
        else if (target < arr[mid]) {
            right = mid - 1;
        }
        else {
            left = mid + 1;
        }
    }

    return target_index; // Return the index of the target
}

// Sort an array of strings using bubble sort
void bubble_sort(char* arr[], int n) {
    int unsorted = n - 1; 

    while (unsorted > 0) {
        int current = 1; 

        while (current <= unsorted) {
            if (strcmp(arr[current], arr[current - 1]) < 0) {
                // Swap if out of order
                char* temp = arr[current - 1];
                arr[current - 1] = arr[current];
                arr[current] = temp;
            }
            current++;
        }

        unsorted--; 
    }
}

// Check if a character is whitespace
int is_whitespace(char ch) {
    return ch == ' ' || ch == '\t' || ch == '\n' || ch == '\r';
}

// Recursive function to check if a stringing is a palindrome
int is_palindrome(const char* string, int start, int end) {

    while (start < end && is_whitespace(string[start])) {
        start++;
    }

    // Skip whitespace at the end
    while (end > start && is_whitespace(string[end])) {
        end--;
    }

    if (start >= end) { 
        return 1;
    }

    if (string[start] != string[end]) { 
        return 0;
    }

    // Recursive call moving towards the center
    return is_palindrome(string, start + 1, end - 1);
}

// Check if a number is prime
int is_prime(unsigned int n) {
    if (n < 2) {
        return 0; 
    }
    if (n == 2) {
        return 1; 
    }
    if (n % 2 == 0) {
        return 0; 
    }

    // Check for divisibility by odd numbers up to the square root of 'n'
    for (unsigned int i = 3; i <= sqrt(n); i += 2) {
        if (n % i == 0) {
            return 0; 
        }
    }

    return 1; 
}

// Recursive function to sum all primes from 2 to 'n'
unsigned int sum_primes(unsigned int n) {
    if (n < 2) {
        return 0;
    }
    unsigned int current_prime = 0;
    if (is_prime(n)) {
        current_prime = n; 
    }
    // Recursive call with 'n - 1'
    return current_prime + sum_primes(n - 1);
}

// Calculate character frequencies and find the character with maximum occurrences
void maximum_occurences(const char* string, Occurrences occ[], int* max_occurrences, char* max_char) {
    int count[128] = { 0 }; 
    int total_characters = 0; 

    // Count occurrences of valid characters
    for (const char* p = string; *p; p++) {
        char ch = *p;
        if ((ch >= '0' && ch <= '9') || (ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z') || ch == ' ') {
            count[ch]++;
            total_characters++; 
        }
    }

    // Calculate frequency and fill the 'occurrences' array
    for (int i = 0; i < 128; i++) {
        occ[i].num_occurrences = count[i]; 
        occ[i].frequency = total_characters > 0 ? (double)count[i] / total_characters : 0.0; // Calculate frequency
    }

    // Determine the character with the maximum occurrences
    *max_occurrences = 0;
    for (int i = 0; i < 128; i++) {
        if (count[i] > *max_occurrences) { 
            *max_occurrences = count[i]; 
            *max_char = (char)i; 
        }
    }
}
