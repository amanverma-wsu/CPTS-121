#ifndef FUNCTION_H
#define FUNCTION_H


/*
Function: max_consecutive_integers
- Description: Finds the longest sequence of consecutive numbers in a 2D matrix.
- Input:
  - matrix: Pointer to a 2D array of integers.
  - rows: Number of rows.
  - cols: Number of columns.
  - start_address: Pointer to store the starting address of the longest sequence.
  - count: Pointer to store the count of the longest sequence.
- Returns: None (results are returned via pointers).
- Preconditions: The matrix must be valid.
- Postconditions: The longest sequence's start address and count are updated.
*/
void max_consecutive_integers(int** matrix, int rows, int cols, int* start_address, int* count);


/*
Function: my_str_n_cat
- Description: Concatenates up to 'n' characters from 'src' to the end of 'dest'.
- Input:
  - dest: Pointer to the destination string.
  - src: Pointer to the source string.
  - n: Maximum number of characters to add.
- Returns: The destination string with added characters.
- Preconditions: The destination string must have space for additional characters.
- Postconditions: 'dest' is updated with the new characters from 'src'.
*/
char* my_str_n_cat(char* dest, const char* src, int n);


/*
Function: binary_search
- Description: Searches for a target in a sorted array of integers.
- Input:
  - arr: Pointer to the array.
  - size: Size of the array.
  - target: The value to find.
- Returns: Index of 'target' if found, -1 if not.
- Preconditions: The array must be sorted in ascending order.
- Postconditions: Returns the index of 'target' or -1 if not found.
*/
int binary_search(const int arr[], int size, int target);


/*
Function: bubble_sort
- Description: Sorts an array of strings using bubble sort.
- Input:
  - arr: Pointer to an array of pointers to strings.
  - n: Number of elements.
- Returns: None (the array is sorted in place).
- Preconditions: The array should contain valid strings.
- Postconditions: The array is sorted.
*/
void bubble_sort(char* arr[], int n);


/*
Function: is_palindrome
- Description: Checks if a string reads the same forwards and backwards (ignores whitespace).
- Input:
  - str: Pointer to the string.
  - start: Start index.
  - end: End index.
- Returns: 1 if it's a palindrome, 0 otherwise.
- Preconditions: The input string must be valid.
- Postconditions: Returns if the string is a palindrome or not.
*/
int is_palindrome(const char* str, int start, int end);


/*
Function: is_whitespace
- Description: Checks if a character is whitespace (space, tab, newline, etc.).
- Input:
  - ch: The character to check.
- Returns: 1 if it's whitespace, 0 otherwise.
- Preconditions: None.
- Postconditions: Indicates whether the character is whitespace.
*/
int is_whitespace(char ch);


/*
Function: sum_primes
- Description: Recursively sums all prime numbers from 2 to 'n'.
- Input:
  - n: The upper limit for prime numbers.
- Returns: The total sum of prime numbers from 2 to 'n'.
- Preconditions: 'n' should be a non-negative integer.
- Postconditions: Returns the sum of prime numbers.
*/
unsigned int sum_primes(unsigned int n);


/*
Function: is_prime
- Description: Checks if a given number is a prime number.
- Input:
  - n: The number to check.
- Returns: 1 if it's prime, 0 otherwise.
- Preconditions: 'n' should be a positive integer.
- Postconditions: Returns if the number is prime or not.
*/
int is_prime(unsigned int n);


/*
Function: maximum_occurences
- Description: Calculates the frequency of each character in a string and finds the character with the most occurrences.
- Input:
  - str: Pointer to the string.
  - occ: Pointer to an array of 'Occurrences' structs to store frequency and occurrences.
  - max_occurrences: Pointer to store the maximum number of occurrences.
  - max_char: Pointer to store the character with the most occurrences.
- Returns: None (results are stored in the 'occ' array and through pointers).
- Preconditions: The string must be valid.
- Postconditions: Frequencies are calculated, and the character with the most occurrences is identified.
*/
typedef struct occurrences {
    int num_occurrences; // Number of times a character occurs
    double frequency; // Frequency of the character in the string
} Occurrences;
void maximum_occurences(const char* str, Occurrences occ[], int* max_occurrences, char* max_char);
#endif
