#include <stdio.h> 
#include <string.h> 
#include "header.h"

int main() {
    int rows = 4;
    int columns = 5;

    char destination[20] = "Hello";
    const char* src = " World!";
    int n_concat = 3;

    int int_array[] = { 1, 3, 5, 7, 9, 11, 13, 15, 17, 19 };
    int int_size = sizeof(int_array) / sizeof(int_array[0]);
    int target = 7;
    int search_result = binary_search(int_array, int_size, target);

    if (search_result != -1) {
        printf("Target found at index: %d\n", search_result);
    }
    else {
        printf("Target not found in the list.\n");
    }

    // Frequency and occurrences
    const char* test_str = "test string"; 
    Occurrences occ[128]; 
    int max_occurrences = 0; 
    char max_char = '\0'; 

    maximum_occurences(test_str, occ, &max_occurrences, &max_char);

    printf("Character with maximum occurrences: '%c'\n", max_char);
    printf("Maximum occurrences: %d\n", max_occurrences);

    // Display frequency information for all valid characters
    for (int i = 0; i < 128; i++) {
        if (occ[i].num_occurrences > 0) {
            printf("Character '%c' occurs %d times with frequency %.2f%%\n", (char)i, occ[i].num_occurrences, occ[i].frequency * 100);
        }
    }

    // Bubble sort
    char* str_array[] = { "banana", "apple", "orange", "grape", "pineapple" };
    int str_size = sizeof(str_array) / sizeof(str_array[0]);
    bubble_sort(str_array, str_size);

    printf("Sorted arrayay:\n");
    for (int i = 0; i < str_size; i++) {
        printf("%s\n", str_array[i]);
    }

    // Palindrome check
    const char* palindrome_str = "race car"; 
    int str_len = strlen(palindrome_str) - 1;
    int palindrome_result = is_palindrome(palindrome_str, 0, str_len);

    if (palindrome_result == 1) {
        printf("'%s' is a palindrome.\n", palindrome_str);
    }
    else {
        printf("'%s' is not a palindrome.\n", palindrome_str);
    }

    // Consecutive integers
    int arrayay[4][5] = {
        {-5, 6, 0, 2, 2},
        {2, 2, 2, 9, 3},
        {3, 3, 2, 1, -8},
        {7, -2, 6, 0, 4}
    };

    int* matrix[4]; // arrayay of pointers to arrayays
    for (int i = 0; i < 4; i++) {
        matrix[i] = (int*)arrayay[i]; // Explicit cast for pointer-to-pointer
    }

    int starting_address = 0;
    int count = 0;

    max_consecutive_integers(matrix, rows, columns, &starting_address, &count);

    printf("Start address: %d\n", starting_address);
    printf("Count of consecutive same integers: %d\n", count);

    // Concatenation result
    my_str_n_cat(destination, src, n_concat);
    printf("Resulting string: %s\n", destination);

    return 0; 
}
