#define _CRT_SECURE_NO_WARNINGS
#ifndef HEADER_H
#define HEADER_H

#include <stdio.h>

/****************************************************************************
* Function: read_double()                                                    *
* Date Created: 2/7/24                                                       *
* Date Last Modified: 2/9/24                                                 *
* Description: This function reads a double from a file.                     *
*                                                                            *
* Input parameters:                                                          *
*   FILE* infile - Pointer to the input file                                 *
*                                                                            *
* Returns: The read double value                                             *
*                                                                            *
* Preconditions: None                                                        *
* Postconditions: The read double value is returned.                         *
******************************************************************************/
double read_double(FILE* infile);




/****************************************************************************
* Function: read_integer()                                                   *
* Date Created: 2/7/24                                                       *
* Date Last Modified:2/9/24                                                  *
* Description: This function reads an integer from a file.                   *
*                                                                            *
* Input parameters:                                                          *
*   FILE* infile - Pointer to the input file                                 *
*                                                                            *
* Returns: The read integer value                                            *
*                                                                            *
* Preconditions: None                                                        *
* Postconditions: The read integer value is returned.                        *
******************************************************************************/
int read_integer(FILE* infile);




/****************************************************************************
* Function: calculate_sum()                                                  *
* Date Created: 2/7/24                                                       *
* Date Last Modified: 2/9/24                                                 *
* Description: This function calculates the sum of five numbers.             *
*                                                                            *
* Input parameters:                                                          *
*   double number1 - First number                                            *
*   double number2 - Second number                                           *
*   double number3 - Third number                                            *
*   double number4 - Fourth number                                           *
*   double number5 - Fifth number                                            *
*                                                                            *
* Returns: The sum of the five numbers                                       *
*                                                                            *
* Preconditions: None                                                        *
* Postconditions: The sum of the five numbers is returned.                   *
******************************************************************************/
double calculate_sum(double number1, double number2, double number3, double number4, double number5);




/****************************************************************************
* Function: calculate_mean()                                                 *
* Date Created: 2/7/24                                                       *
* Date Last Modified: 2/9/24                                                 *
* Description: This function calculates the mean of a set of numbers.        *
*                                                                            *
* Input parameters:                                                          *
*   double sum - Sum of the numbers                                          *
*   int number - Number of values in the set                                 *
*                                                                            *
* Returns: The mean of the set of numbers                                    *
*                                                                            *
* Preconditions: None                                                        *
* Postconditions: The mean of the set of numbers is returned.                *
******************************************************************************/
double calculate_mean(double sum, int number);


/****************************************************************************
* Function: calculate_deviation()                                            *
* Date Created: 2/7/24                                                       *
* Date Last Modified: 2/9/24                                                 *
* Description: This function calculates the deviation of a number from the   *
*              mean.                                                         *
*                                                                            *
* Input parameters:                                                          *
*   double number - Number to calculate deviation for                        *
*   double mean - Mean of the set of numbers                                 *
*                                                                            *
* Returns: The deviation of the number from the mean                         *
*                                                                            *
* Preconditions: None                                                        *
* Postconditions: The deviation of the number from the mean is returned.     *
******************************************************************************/
double calculate_deviation(double number, double mean);


/****************************************************************************
* Function: calculate_variance()                                             *
* Date Created: 2/7/24                                                       *
* Date Last Modified: 2/9/24                                                 *
* Description: This function calculates the variance of a set of numbers.    *
*                                                                            *
* Input parameters:                                                          *
*   double deviation1 - Deviation of first number from mean                  *
*   double deviation2 - Deviation of second number from mean                 *
*   double deviation3 - Deviation of third number from mean                  *
*   double deviation4 - Deviation of fourth number from mean                 *
*   double deviation5 - Deviation of fifth number from mean                  *
*                                                                            *
* Returns: The variance of the set of numbers                                *
*                                                                            *
* Preconditions: None                                                        *
* Postconditions: The variance of the set of numbers is returned.            *
******************************************************************************/
double calculate_variance(double deviation1, double deviation2, double deviation3, double deviation4, double deviation5);


/****************************************************************************
* Function: calculate_standard_deviation()                                   *
* Date Created: 2/7/24                                                       *
* Date Last Modified: 2/9/24                                                 *
* Description: This function calculates the standard deviation from the      *
*              variance.                                                     *
*                                                                            *
* Input parameters:                                                          *
*   double variance - Variance of the set of numbers                         *
*                                                                            *
* Returns: The standard deviation                                            *
*                                                                            *
* Preconditions: None                                                        *
* Postconditions: The standard deviation is returned.                        *
******************************************************************************/
double calculate_standard_deviation(double variance);


/****************************************************************************
* Function: find_max()                                                       *
* Date Created: 2/7/24                                                       *
* Date Last Modified: 2/9/24                                                 *
* Description: This function finds the maximum of five numbers.              *
*                                                                            *
* Input parameters:                                                          *
*   double number1 - First number                                            *
*   double number2 - Second number                                           *
*   double number3 - Third number                                            *
*   double number4 - Fourth number                                           *
*   double number5 - Fifth number                                            *
*                                                                            *
* Returns: The maximum number                                                *
*                                                                            *
* Preconditions: None                                                        *
* Postconditions: The maximum number is returned.                            *
******************************************************************************/
double find_max(double number1, double number2, double number3, double number4, double number5);

/****************************************************************************
* Function: find_min()                                                       *
* Date Created: 2/7/24                                                       *
* Date Last Modified: 2/9/24                                                 *
* Description: This function finds the minimum of five numbers.              *
*                                                                            *
* Input parameters:                                                          *
*   double number1 - First number                                            *
*   double number2 - Second number                                           *
*   double number3 - Third number                                            *
*   double number4 - Fourth number                                           *
*   double number5 - Fifth number                                            *
*                                                                            *
* Returns: The minimum number                                                *
*                                                                            *
* Preconditions: None                                                        *
* Postconditions: The minimum number is returned.                            *
******************************************************************************/
double find_min(double number1, double number2, double number3, double number4, double number5);


/****************************************************************************
* Function: print_double()                                                   *
* Date Created: 2/7/24                                                       *
* Date Last Modified: 9/2/24                                                 *
* Description: This function prints a double to a file.                      *
*                                                                            *
* Input parameters:                                                          *
*   FILE* outfile - Pointer to the output file                               *
*   double number - Double to be printed                                     *
*                                                                            *
* Returns: None                                                              *
*                                                                            *
* Preconditions: None                                                        *
* Postconditions: The double is printed to the file.                         *
******************************************************************************/
void print_double(FILE* outfile, double number);

#endif
