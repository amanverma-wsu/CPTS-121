#define _CRT_SECURE_NO_WARNINGS
#include "header.h"              
#include <math.h>               


double read_double(FILE* infile) {
    double number;                      // Variable to store the read double.
    fscanf(infile, "%lf", &number);     // Read double from file.
    return number;                      // Return the read double.
}


int read_integer(FILE* infile) {
    int number;                        // Variable to store the read integer.
    fscanf(infile, "%d", &number);     // Read integer from file.
    return number;                     // Return the read integer.
}


double calculate_sum(double number1, double number2, double number3, double number4, double number5) {
    return number1 + number2 + number3 + number4 + number5;  // Return the sum of five numbers.
}


double calculate_mean(double sum, int number) {
    return sum / number;        // Return the mean of the set of numbers.
}


double calculate_deviation(double number, double mean) {
    return number - mean;       // Return the deviation of the number from the mean.
}


double calculate_variance(double deviation1, double deviation2, double deviation3, double deviation4, double deviation5) {
    double sum_squared_deviations = pow(deviation1, 2) + pow(deviation2, 2) + pow(deviation3, 2) + pow(deviation4, 2) + pow(deviation5, 2); // Calculate the sum of squared deviations.
    double mean_squared_deviations = sum_squared_deviations / 5;    // Calculate the mean of squared deviations.
    double squared_mean_deviation = pow(calculate_mean(deviation1, 5), 2);   // Calculate the squared mean deviation.
    return mean_squared_deviations - squared_mean_deviation;   // Return the variance.
}


double calculate_standard_deviation(double variance) {
    return sqrt(variance);      // Return the square root of variance (standard deviation).
}


double find_max(double number1, double number2, double number3, double number4, double number5) {
    double max = number1;       // Assume the first number is the maximum.
    if (number2 > max)          // If the second number is greater than the current max, update max.
        max = number2;
    if (number3 > max)          // If the third number is greater than the current max, update max.
        max = number3;
    if (number4 > max)          // If the fourth number is greater than the current max, update max.
        max = number4;
    if (number5 > max)          // If the fifth number is greater than the current max, update max.
        max = number5;
    return max;                 // Return the maximum number.
}


double find_min(double number1, double number2, double number3, double number4, double number5) {
    double min = number1;       // Assume the first number is the minimum.
    if (number2 < min)          // If the second number is less than the current min, update min.
        min = number2;
    if (number3 < min)          // If the third number is less than the current min, update min.
        min = number3;
    if (number4 < min)          // If the fourth number is less than the current min, update min.
        min = number4;
    if (number5 < min)          // If the fifth number is less than the current min, update min.
        min = number5;
    return min;                 // Return the minimum number.
}


void print_double(FILE* outfile, double number) {
    fprintf(outfile, "%.2lf", number); // Print the double to the file with two decimal places.
}
