#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include "header.h"

int main() {
    FILE* infile, * outfile;
    double gpa1, gpa2, gpa3, gpa4, gpa5;
    double sum_gpa, mean_gpa, deviation1, deviation2, deviation3, deviation4, deviation5, variance, std_deviation;
    double max_gpa, min_gpa;
    int class1, class2, class3, class4, class5;
    double sum_class, mean_class;
    double age1, age2, age3, age4, age5;
    double sum_age, mean_age;
    int student_id; // Add student_id variable to read and discard student ID

    // Open input file
    infile = fopen("input.dat", "r");

    // Open output file
    outfile = fopen("output.dat", "w");

    // Read first record
    student_id = read_integer(infile); // Read and discard student ID
    gpa1 = read_double(infile);
    class1 = read_integer(infile);
    age1 = read_double(infile);

    // Read second record
    student_id = read_integer(infile); // Read and discard student ID
    gpa2 = read_double(infile);
    class2 = read_integer(infile);
    age2 = read_double(infile);

    // Read third record
    student_id = read_integer(infile); // Read and discard student ID
    gpa3 = read_double(infile);
    class3 = read_integer(infile);
    age3 = read_double(infile);

    // Read fourth record
    student_id = read_integer(infile); // Read and discard student ID
    gpa4 = read_double(infile);
    class4 = read_integer(infile);
    age4 = read_double(infile);

    // Read fifth record
    student_id = read_integer(infile); // Read and discard student ID
    gpa5 = read_double(infile);
    class5 = read_integer(infile);
    age5 = read_double(infile);

    // Close input file
    fclose(infile);

    // Calculate sum of GPAs, class standings, and ages
    sum_gpa = calculate_sum(gpa1, gpa2, gpa3, gpa4, gpa5);
    sum_class = calculate_sum(class1, class2, class3, class4, class5);
    sum_age = calculate_sum(age1, age2, age3, age4, age5);

    // Calculate means
    mean_gpa = calculate_mean(sum_gpa, 5);
    mean_class = calculate_mean(sum_class, 5);
    mean_age = calculate_mean(sum_age, 5);

    // Calculate deviation of each GPA from the mean
    deviation1 = calculate_deviation(gpa1, mean_gpa);
    deviation2 = calculate_deviation(gpa2, mean_gpa);
    deviation3 = calculate_deviation(gpa3, mean_gpa);
    deviation4 = calculate_deviation(gpa4, mean_gpa);
    deviation5 = calculate_deviation(gpa5, mean_gpa);

    // Calculate variance
    variance = calculate_variance(deviation1, deviation2, deviation3, deviation4, deviation5);

    // Calculate standard deviation
    std_deviation = calculate_standard_deviation(variance);

    // Find min and max GPAs
    min_gpa = find_min(gpa1, gpa2, gpa3, gpa4, gpa5);
    max_gpa = find_max(gpa1, gpa2, gpa3, gpa4, gpa5);

    // Write results to output file
    print_double(outfile, mean_gpa);
    fprintf(outfile, " -- GPA Mean\n");

    print_double(outfile, mean_class);
    fprintf(outfile, " -- Class Standing Mean\n");

    print_double(outfile, mean_age);
    fprintf(outfile, " -- Age Mean\n");

    print_double(outfile, std_deviation);
    fprintf(outfile, " -- GPA Standard Deviation\n");

    print_double(outfile, min_gpa);
    fprintf(outfile, " -- GPA Min\n");

    print_double(outfile, max_gpa);
    fprintf(outfile, " -- GPA Max\n");

    // Close output file
    fclose(outfile);

    return 0;
}
